<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Leave Records - Diary Desk</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body>
  <!-- Header -->
  <header class="fade-in-down">
    <div class="header-left">
      <div style="display: flex; align-items: center;">
        <img src="diarydesk logo.png" alt="Diary Desk Logo" style="height: 50px; margin-right: 10px;">
        <h1 style="margin: 0;">Diary Desk</h1>
      </div>
    </div>
    <div class="header-right">
      <!-- Search Bar -->
      <form id="searchForm" method="POST" action="search_results.php">
        <input type="text" name="query" placeholder="Search..." required>
        <button type="submit"><i class="fas fa-search"></i></button>
      </form>
      <div class="profile">
        <span>Welcome, Teacher</span>
        <a href="login.php" class="logout-btn">Logout</a>
      </div>
    </div>
  </header>

  <!-- Sidebar -->
  <aside class="fade-in-left">
    <nav>
      <ul>
        <li><a href="dashboard.html"><i class="fas fa-home"></i>Home</a></li>
        <li><a href="daily.php"><i class="fas fa-calendar-alt"></i>Daily Updates</a></li>
        <li><a href="leave.php" class="active"><i class="fas fa-file-alt"></i>Leave Records</a></li>
        <li><a href="reports.html"><i class="fas fa-chart-line"></i>Reports</a></li>
      </ul>
    </nav>
  </aside>

  <!-- Main Content -->
  <main class="fade-in">
    <section class="fade-in active">
    <h2>Apply for Leave</h2>
    <div class="card">
      <form action="apply_leave.php" method="POST">
        <input type="text" name="teacher_name" placeholder="Enter your name" required>

        <label>Leave Type:</label>
        <select name="leave_type" required>
          <option value="">--Select Type--</option>
          <option value="Sick Leave">Sick Leave</option>
          <option value="Casual Leave">Casual Leave</option>
          <option value="Personal Leave">Personal Leave</option>
        </select>

        <label>Start Date:</label>
        <input type="date" name="start_date" required>

        <label>End Date:</label>
        <input type="date" name="end_date" required>

        <textarea name="reason" rows="4" placeholder="Enter reason for leave..." required></textarea>

        <button type="submit">📨 Apply Leave</button>
      </form>
    </div>

    <div class="card">
      <h3>🗓 Your Leave Applications</h3>
      <?php include 'fetch_leaves.php'; ?>
    </div>
  </section>

  </main>
</body>
</html>
