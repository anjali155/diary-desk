<?php
// Start session
session_start();

// Database connection
include 'config.php';

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    die("<p style='color:red;'>Access denied. Please log in.</p>");
}

// Fetch user_id from session username
$username = $_SESSION['username'];
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("<p style='color:red;'>User not found.</p>");
}

$user_data = $result->fetch_assoc();
$user_id = $user_data['id'];
$stmt->close();

// Initialize results
$report_data = [
    'daily_updates' => [],
    'leave_records' => []
];

if (isset($_POST['generate'])) {
    $report_type = $_POST['report_type'];
    $date = $_POST['date'];

    // Fetch daily updates
    if ($report_type === "daily" || $report_type === "monthly" || $report_type === "annual") {
        $daily_sql = "SELECT * FROM daily_updates WHERE teacher_name = ? AND ";
        if ($report_type === "daily") {
            $daily_sql .= "DATE(update_date) = ?";
            $params = [$username, $date];
        } elseif ($report_type === "monthly") {
            $month = date('m', strtotime($date));
            $year = date('Y', strtotime($date));
            $daily_sql .= "MONTH(update_date) = ? AND YEAR(update_date) = ?";
            $params = [$username, $month, $year];
        } elseif ($report_type === "annual") {
            $year = date('Y', strtotime($date));
            $daily_sql .= "YEAR(update_date) = ?";
            $params = [$username, $year];
        }

        $stmt = $conn->prepare($daily_sql);
        $stmt->bind_param(str_repeat("s", count($params)), ...$params);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows > 0) {
            $report_data['daily_updates'] = $res->fetch_all(MYSQLI_ASSOC);
        }
        $stmt->close();
    }

    // Fetch leave records
    $leave_sql = "SELECT * FROM leaves WHERE teacher_name = ? AND ";
    if ($report_type === "daily") {
        $leave_sql .= "DATE(start_date) <= ? AND DATE(end_date) >= ?";
        $params = [$username, $date, $date];
    } elseif ($report_type === "monthly") {
        $month = date('m', strtotime($date));
        $year = date('Y', strtotime($date));
        $leave_sql .= "MONTH(start_date) = ? AND YEAR(start_date) = ?";
        $params = [$username, $month, $year];
    } elseif ($report_type === "annual") {
        $year = date('Y', strtotime($date));
        $leave_sql .= "YEAR(start_date) = ?";
        $params = [$username, $year];
    }

    $stmt = $conn->prepare($leave_sql);
    $stmt->bind_param(str_repeat("s", count($params)), ...$params);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        $report_data['leaves'] = $res->fetch_all(MYSQLI_ASSOC);
    }
    $stmt->close();
}

// Display results
if (!empty($report_data['daily_updates']) || !empty($report_data['leaves'])) {
    echo "<h3>Report:</h3>";
    echo "<h4>Daily Updates</h4>";
    if (!empty($report_data['daily_updates'])) {
        echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr><th>Teacher Name</th><th>Subject</th><th>Update</th><th>Date</th></tr>";
        foreach ($report_data['daily_updates'] as $row) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['teacher_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['subject']) . "</td>";
            echo "<td>" . nl2br(htmlspecialchars($row['update_text'])) . "</td>";
            echo "<td>" . htmlspecialchars($row['update_date']) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No daily updates found.</p>";
    }

    echo "<h4>Leave Records</h4>";
    if (!empty($report_data['leaves'])) {
        echo "<table border='1' cellpadding='5' cellspacing='0'>";
        echo "<tr><th>Teacher Name</th><th>Leave Type</th><th>Start Date</th><th>End Date</th><th>Reason</th></tr>";
        foreach ($report_data['leaves'] as $row) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['teacher_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['leave_type']) . "</td>";
            echo "<td>" . htmlspecialchars($row['start_date']) . "</td>";
            echo "<td>" . htmlspecialchars($row['end_date']) . "</td>";
            echo "<td>" . nl2br(htmlspecialchars($row['reason'])) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No leave records found.</p>";
    }
} elseif (isset($_POST['generate'])) {
    echo "<p style='color:red;'>No records found for the selected date range.</p>";
}
?>