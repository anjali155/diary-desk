<?php
$servername = "localhost:3307";
$username = "root";
$password = "";
$dbname = "diarydesk";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM leaves ORDER BY id DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table border='0' style='width:100%; border-collapse: collapse;'>";
  echo "<tr style='color:#ff4757; font-weight:bold; text-align:left;'>
          <th>Name</th>
          <th>Type</th>
          <th>Start</th>
          <th>End</th>
          <th>Reason</th>
          <th>Status</th>
          <th>Applied On</th>
        </tr>";

  while($row = $result->fetch_assoc()) {
    echo "<tr style='border-bottom:1px solid rgba(255,255,255,0.1);'>";
    echo "<td>" . htmlspecialchars($row['teacher_name']) . "</td>";
    echo "<td>" . htmlspecialchars($row['leave_type']) . "</td>";
    echo "<td>" . $row['start_date'] . "</td>";
    echo "<td>" . $row['end_date'] . "</td>";
    echo "<td>" . htmlspecialchars($row['reason']) . "</td>";

    // Status color
    $statusColor = ($row['status'] == 'Approved') ? '#6eff9b' : 
                   (($row['status'] == 'Rejected') ? '#ff6b81' : '#ffcc00');
    echo "<td style='color:$statusColor; font-weight:bold;'>" . $row['status'] . "</td>";
    echo "<td>" . $row['applied_on'] . "</td>";
    echo "</tr>";
  }

  echo "</table>";
} else {
  echo "<p style='color:#aaa;'>No leave applications found.</p>";
}

$conn->close();
?>