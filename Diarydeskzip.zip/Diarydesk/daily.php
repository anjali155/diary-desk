<?php
// Database connection
$servername = "localhost:3307";
$username = "root"; // DB username
$password = "";     // DB password
$dbname = "diarydesk";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$success_msg = "";

// Save daily update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $teacher_name = $_POST['teacher_name'];
    $subject = $_POST['subject'];
    $update_text = $_POST['update_text'];

    if (!empty($teacher_name) && !empty($subject) && !empty($update_text)) {
        $stmt = $conn->prepare("INSERT INTO daily_updates (teacher_name, subject, update_text) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $teacher_name, $subject, $update_text);

        if ($stmt->execute()) {
            $success_msg = "Daily update saved successfully!";
        } else {
            $success_msg = "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $success_msg = "Please fill in all fields.";
    }
}

// Fetch all updates
$updates = [];
$result = $conn->query("SELECT * FROM daily_updates ORDER BY update_date DESC");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $updates[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daily Updates - Diary Desk</title>
  <link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body>
  <!-- Header -->
  <header class="fade-in-down">
    <div class="header-left">
      <div style="display: flex; align-items: center;">
        <img src="diarydesk logo.png" alt="Diary Desk Logo" style="height: 50px; margin-right: 10px;">
        <h1 style="margin: 0;">Diary Desk</h1>
      </div>
    </div>
    <div class="header-right">
      <!-- Search Bar -->
      <form id="searchForm" method="POST" action="search_results.php">
        <input type="text" name="query" placeholder="Search..." required>
        <button type="submit"><i class="fas fa-search"></i></button>
      </form>
      <div class="profile">
        <span>Welcome, Teacher</span>
        <a href="login.php" class="logout-btn">Logout</a>
      </div>
    </div>
  </header>

  <!-- Sidebar -->
  <aside class="fade-in-left">
    <nav>
      <ul>
        <li><a href="dashboard.html"><i class="fas fa-home"></i>Home</a></li>
        <li><a href="daily.php" class="active"><i class="fas fa-calendar-alt"></i>Daily Updates</a></li>
        <li><a href="leave.php"><i class="fas fa-file-alt"></i>Leave Records</a></li>
        <li><a href="reports.html"><i class="fas fa-chart-line"></i>Reports</a></li>
      </ul>
    </nav>
  </aside>
  <main class="fade-in">
    <section id="daily">
        <h2>Daily Updates</h2>
<div class="card">
        <?php if($success_msg != "") { echo "<p class='msg'>$success_msg</p>"; } ?>

        <form method="POST" action="">
            <input type="text" name="teacher_name" placeholder="Teacher Name">
            <input type="text" name="subject" placeholder="Subject">
            <textarea name="update_text" rows="5" placeholder="Write your daily update here..."></textarea>
            <button type="submit">Save Update</button>
        </form>

        <?php if(!empty($updates)) { ?>
            <h3>Previous Updates</h3>
            <table>
                <tr>
                    <th>Teacher Name</th>
                    <th>Subject</th>
                    <th>Update</th>
                    <th>Date</th>
                </tr>
                <?php foreach($updates as $u) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($u['teacher_name']); ?></td>
                        <td><?php echo htmlspecialchars($u['subject']); ?></td>
                        <td><?php echo nl2br(htmlspecialchars($u['update_text'])); ?></td>
                        <td><?php echo $u['update_date']; ?></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } ?>
    </div>
  </div>
</section>
  </main>
