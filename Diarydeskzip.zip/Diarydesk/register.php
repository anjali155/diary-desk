<?php
include 'config.php';
session_start();
$showAlert = "";

if (isset($_POST['register'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if username or email already exists
    $checkUser = mysqli_query($conn, "SELECT * FROM users WHERE username='$username' OR email='$email'");
    
    if (mysqli_num_rows($checkUser) > 0) {
        $showAlert = "Username or email already exists!";
    } else {
        $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";
        $result = mysqli_query($conn, $sql); 
        
        if ($result) {
            $showAlert = "Registration successful! Redirecting to login...";
            echo "<script>
                alert('$showAlert');
                window.location='login.php';
            </script>";
            exit();
        } else {
            $showAlert = "Error: Unable to register. " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Teacher's Diary - Register</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f4f9;
      color: #333;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .container {
      background: #ffffff;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      text-align: center;
      width: 100%;
      max-width: 400px;
    }
    h2 {
      margin-bottom: 1.5rem;
      font-size: 1.5rem;
      color: #444;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    input {
      padding: 0.8rem;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-size: 1rem;
      outline: none;
      transition: border-color 0.3s;
    }

    input:focus {
      border-color: #007bff;
    }
    button {
      padding: 0.8rem;
      background-color: #007bff;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 1rem;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    button:hover {
      background-color: #0056b3;
    }
    a {
      display: block;
      margin-top: 1rem;
      color: #007bff;
      text-decoration: none;
      font-size: 0.9rem;
    }

    a:hover {
      text-decoration: underline;
    }

  </style>
</head>
<body>
  <?php
  if ($showAlert != "") {
      echo "<script>alert('$showAlert');</script>";
  } 
  ?>
  <div class="container">
    <h2>📝 Register</h2>
    <form method="POST">
      <input type="text" name="username" placeholder="👤 Username" required>
      <input type="email" name="email" placeholder="📧 Email" required>
      <input type="password" name="password" placeholder="🔑 Password" required>
      <button type="submit" name="register" value="Register">Register</button>
    </form>
    <a href="login1.php">Already have an account? Login</a>
  </div>
</body>
</html>