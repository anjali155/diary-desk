<?php
$servername = "localhost:3307";
$username = "root";
$password = "";
$dbname = "diarydesk";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$teacher_name = $_POST['teacher_name'];
$leave_type = $_POST['leave_type'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$reason = $_POST['reason'];

$sql = "INSERT INTO leaves (teacher_name, leave_type, start_date, end_date, reason)
        VALUES ('$teacher_name', '$leave_type', '$start_date', '$end_date', '$reason')";

if ($conn->query($sql) === TRUE) {
  echo "<script>alert('✅ Leave application submitted successfully!'); window.location.href='leave.php';</script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>