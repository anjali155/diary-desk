<?php
include ('config.php');
echo "Database Connection successfully!";
?>